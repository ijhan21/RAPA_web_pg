const a = 'Mark';
console.log(a, typeof a)


//템플릿 스트링, 백틱,
const b = `${a} + hello`
console.log(b)