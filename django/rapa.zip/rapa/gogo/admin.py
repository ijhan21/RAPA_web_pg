from django.contrib import admin
from gogo.models import CCchoiceA, CCquestionA
# Register your models here.
admin.site.register(CCquestionA)
admin.site.register(CCchoiceA)