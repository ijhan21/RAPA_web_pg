from django.contrib import admin
from gogo.models import Cchoise1, Cquestion1
# Register your models here.
admin.site.register(Cchoise1)
admin.site.register(Cquestion1)