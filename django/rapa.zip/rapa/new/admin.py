from django.contrib import admin
from new.models import Cchoise, Cquestion
# Register your models here.
admin.site.register(Cchoise)
admin.site.register(Cquestion)